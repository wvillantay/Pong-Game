using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class player1 : MonoBehaviour
{
    public float RacketSpeed;
    public Rigidbody2D rb;
    Vector2 RacketDirection;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        float DirectionY = Input.GetAxisRaw("vertical2");
        RacketDirection = new Vector2(0, DirectionY).normalized;
    }
    private void FixedUpdate()
    {
        rb.velocity = RacketDirection * RacketSpeed;
    }
}
