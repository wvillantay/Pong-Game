using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallMovement : MonoBehaviour
{
    public float StartSpeed, ExtraSpeed, MaxSpeed;
    int hitCounter=0;
    Rigidbody2D rb;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        StartCoroutine(LaunchBall());
    }

   

    public void MoveBall(Vector2 direction)
    {
        direction = direction.normalized;
        float ballspeed = StartSpeed + hitCounter * ExtraSpeed;
        rb.velocity = direction * ballspeed;
    }

    public IEnumerator LaunchBall()
    {
        hitCounter = 0;
        yield return new WaitForSeconds(1f);
        MoveBall(new Vector2(-1, 0));
    }

    public void increasehitcounter()
    {
        if(hitCounter*ExtraSpeed<MaxSpeed)
        {
            hitCounter++;
        }
    }
}
