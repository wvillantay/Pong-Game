using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BounceBall : MonoBehaviour
{
    public BallMovement ballmovement;
    public GameObject[] ObjectstoDisapear;
    public GameObject player1win;
    public GameObject player2win;
    public GameObject player1lost;
    public GameObject player2lost;
    public GameObject PongGlow;
    public GameObject playerAgain;
    public AudioSource As;

    public void bounce(Collision2D col)
    {
        Vector3 ballpos = transform.position;
        Vector3 playerpos = col.transform.position;
        float RacketHight = col.collider.bounds.size.y;
        float PosX;
        if (col.gameObject.CompareTag("Player1"))
        {
            PosX = 1;
            As.Play();
        }
        else
        {
            As.Play();

            PosX = -1;
        }
        float PosY = (ballpos.y - playerpos.y) / RacketHight;
        ballmovement.increasehitcounter();
        ballmovement.MoveBall(new Vector2(PosX, PosY));
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.CompareTag("Player1") || collision.gameObject.CompareTag("Player2"))
        {

            bounce(collision);
        }
        if(collision.gameObject.CompareTag("LeftBorder"))
        {
            //for(int i=0;i<ObjectstoDisapear.Length;i++)
            //{
            //    ObjectstoDisapear[i].SetActive(false);
            //}
            //player2wins
           
            StartCoroutine(ShowGameOverMenu(2));

        }
        if (collision.gameObject.CompareTag("RightBorder"))
        {
           
         
            StartCoroutine(ShowGameOverMenu(1));

        }

    }

    IEnumerator ShowGameOverMenu(int whichplayer)
    {
        yield return null;
        PongGlow.SetActive(true);
        playerAgain.SetActive(true);
        for (int i = 0; i < ObjectstoDisapear.Length; i++)
        {
            ObjectstoDisapear[i].SetActive(false);
        }

        if(whichplayer==1)
        {
            player1win.SetActive(true);
           
        }
        if(whichplayer==2)
        {
            player2win.SetActive(true);
           
        }
    }
}
