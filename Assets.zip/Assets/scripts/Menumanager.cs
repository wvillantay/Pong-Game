using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Menumanager : MonoBehaviour
{
    public GameObject Glowpong;
    public GameObject changecolor;
    public GameObject playbuttton;
    public GameObject[] ObjectstoApear;
    // Start is called before the first frame update
    void Start()
    {
        Time.timeScale = 1f;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void PlayGame()
    {
        Glowpong.SetActive(false);
        playbuttton.SetActive(false);
        changecolor
            .SetActive(false);

        for(int i=0;i<ObjectstoApear.Length;i++)
        {
            ObjectstoApear[i].SetActive(true);
        }


    }
}
